# Advanced Animation Guide

Comprehensive guide for building complex animations using GSAP, Framer Motion, and the custom animation hooks.

## Table of Contents
1. [GSAP Basics](#gsap-basics)
2. [Framer Motion Patterns](#framer-motion-patterns)
3. [Scroll Animations](#scroll-animations)
4. [3D Transforms](#3d-transforms)
5. [Text Animations](#text-animations)
6. [Performance Tips](#performance-tips)
7. [Real-World Examples](#real-world-examples)

---

## GSAP Basics

### Timeline Animation
Sequences multiple animations together:

```tsx
import gsap from 'gsap';

const timeline = gsap.timeline();

// Add animations sequentially
timeline
  .to('.element1', { opacity: 1, duration: 0.5 })
  .to('.element2', { y: -20, duration: 0.5 })
  .to('.element3', { scale: 1.2, duration: 0.5 }, '-=0.2'); // Overlap
```

### Staggered Animation
Animates multiple elements with delay:

```tsx
gsap.to('.card', {
  y: 0,
  opacity: 1,
  duration: 0.6,
  stagger: 0.1, // 0.1s delay between each element
  ease: 'power2.out',
});
```

### Yoyo Animation
Element animates back and forth:

```tsx
gsap.to('.bounce', {
  y: -50,
  duration: 0.5,
  yoyo: true,
  repeat: -1, // Infinite repeat
  ease: 'sine.inOut',
});
```

---

## Framer Motion Patterns

### Shared Layout Animation
Animates between different states:

```tsx
import { motion, AnimatePresence } from 'framer-motion';

export function LayoutSwitch() {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      layout
      onClick={() => setIsExpanded(!isExpanded)}
      initial={{ borderRadius: 10 }}
      animate={{ borderRadius: isExpanded ? 20 : 10 }}
      className="bg-white p-4 cursor-pointer"
    >
      {isExpanded && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          Expanded content
        </motion.div>
      )}
    </motion.div>
  );
}
```

### Gesture Animation
Responds to user interactions:

```tsx
<motion.button
  whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(0,0,0,0.3)' }}
  whileTap={{ scale: 0.95 }}
  transition={{ type: 'spring', stiffness: 400, damping: 17 }}
>
  Click Me
</motion.button>
```

### Drag Animation
Full drag with constraints:

```tsx
<motion.div
  drag
  dragConstraints={{ left: -100, right: 100, top: -50, bottom: 50 }}
  dragElastic={0.2}
  onDragEnd={(event, info) => {
    console.log('Dragged distance:', info.offset.x);
  }}
/>
```

---

## Scroll Animations

### Scroll Progress Bar
Shows scroll position:

```tsx
import { motion, useScroll } from 'framer-motion';

export function ProgressBar() {
  const { scrollYProgress } = useScroll();

  return (
    <motion.div
      style={{
        scaleX: scrollYProgress,
        transformOrigin: '0%',
      }}
      className="fixed top-0 left-0 right-0 h-1 bg-white"
    />
  );
}
```

### Scroll-Triggered Animation
Trigger on scroll intersection:

```tsx
const ref = useRef(null);
const { scrollYProgress } = useScroll({
  target: ref,
  offset: ['start end', 'end start'],
});

const y = useTransform(scrollYProgress, [0, 1], [100, -100]);

return (
  <motion.div ref={ref} style={{ y }}>
    Parallax content
  </motion.div>
);
```

### Horizontal Scroll Snap
Like a carousel but with scroll:

```tsx
gsap.to('.scroll-container', {
  x: () => -(document.querySelector('.scroll-container')?.scrollWidth - window.innerWidth),
  scrollTrigger: {
    trigger: '.scroll-container',
    start: 'center center',
    end: 'center -500px',
    scrub: 1,
    snap: 1 / 6, // Snap to nearest item
  },
});
```

---

## 3D Transforms

### Rotating Phone Hero
Premium 3D phone display:

```tsx
useEffect(() => {
  const phone = phoneRef.current;
  
  // Auto-rotate
  gsap.to(phone, {
    rotationY: 360,
    duration: 8,
    repeat: -1,
    ease: 'none',
  });

  // Mouse follow on move
  const handleMouse = (e) => {
    const x = (e.clientX / window.innerWidth) * 2 - 1;
    const y = (e.clientY / window.innerHeight) * 2 - 1;

    gsap.to(phone, {
      rotationY: x * 20,
      rotationX: y * 20,
      duration: 0.3,
      overwrite: 'auto',
    });
  };

  window.addEventListener('mousemove', handleMouse);
  return () => window.removeEventListener('mousemove', handleMouse);
}, []);
```

### Perspective Transform
Creating 3D depth:

```tsx
<div style={{ perspective: '1000px' }}>
  <motion.div
    style={{
      rotateX: 45,
      rotateY: 45,
      transformStyle: 'preserve-3d',
    }}
  >
    3D Card Content
  </motion.div>
</div>
```

---

## Text Animations

### Letter Stagger
Reveals text letter by letter:

```tsx
const letterVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.05,
      duration: 0.3,
    },
  }),
};

export function TextReveal({ text }: { text: string }) {
  return (
    <div>
      {text.split('').map((char, i) => (
        <motion.span
          key={i}
          custom={i}
          variants={letterVariants}
          initial="hidden"
          animate="visible"
        >
          {char}
        </motion.span>
      ))}
    </div>
  );
}
```

### Word Reveal
Reveals text word by word:

```tsx
const wordVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: {
      delay: i * 0.1,
      duration: 0.5,
    },
  }),
};

export function WordReveal({ text }: { text: string }) {
  const words = text.split(' ');
  
  return (
    <div className="flex flex-wrap">
      {words.map((word, i) => (
        <motion.span
          key={i}
          custom={i}
          variants={wordVariants}
          initial="hidden"
          whileInView="visible"
          className="mr-2"
        >
          {word}
        </motion.span>
      ))}
    </div>
  );
}
```

### Typewriter Effect
Types out text in real-time:

```tsx
export function TypeWriter({ text, speed = 50 }: { text: string; speed?: number }) {
  const [displayedText, setDisplayedText] = useState('');
  
  useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      if (index < text.length) {
        setDisplayedText(text.slice(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
      }
    }, speed);
    
    return () => clearInterval(interval);
  }, [text, speed]);
  
  return <span>{displayedText}</span>;
}
```

---

## Performance Tips

### GPU Acceleration
Use only transform and opacity for animations:

```tsx
// ✅ GOOD - GPU accelerated
gsap.to('.element', {
  x: 100,
  y: 50,
  opacity: 0.5,
  duration: 1,
});

// ❌ AVOID - Not GPU accelerated
gsap.to('.element', {
  left: 100,
  top: 50,
  width: 200,
  duration: 1,
});
```

### Will-Change Property
Hint the browser about upcoming animations:

```css
.animated-element {
  will-change: transform, opacity;
}
```

Remove after animation completes to save memory.

### Debounce Scroll Events
Prevent excessive event firing:

```tsx
const handleScroll = gsap.utils.debounce(() => {
  // Animation logic
}, 100);

useEffect(() => {
  window.addEventListener('scroll', handleScroll);
  return () => window.removeEventListener('scroll', handleScroll);
}, []);
```

### Memory Cleanup
Always kill animations and event listeners:

```tsx
useEffect(() => {
  const animation = gsap.to('.element', { /* ... */ });
  const timeline = gsap.timeline();

  return () => {
    animation.kill();
    timeline.kill();
    ScrollTrigger.getAll().forEach(trigger => trigger.kill());
  };
}, []);
```

---

## Real-World Examples

### Magnetic Hover Button

```tsx
function MagneticButton() {
  const buttonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const button = buttonRef.current;
    if (!button) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = button.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const distanceX = e.clientX - centerX;
      const distanceY = e.clientY - centerY;
      const distance = Math.sqrt(distanceX ** 2 + distanceY ** 2);

      if (distance < 100) {
        gsap.to(button, {
          x: (distanceX * 20) / 100,
          y: (distanceY * 20) / 100,
          duration: 0.3,
        });
      }
    };

    const handleMouseLeave = () => {
      gsap.to(button, {
        x: 0,
        y: 0,
        duration: 0.5,
        ease: 'elastic.out(1, 0.5)',
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    button.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      button.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  return <button ref={buttonRef}>Hover Me</button>;
}
```

### Animated Counter

```tsx
function Counter({ target = 100 }: { target?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const countRef = useRef(0);

  useEffect(() => {
    if (!ref.current) return;

    gsap.to(countRef, {
      current: target,
      duration: 2,
      ease: 'power2.out',
      onUpdate: () => {
        if (ref.current) {
          ref.current.textContent = Math.ceil(countRef.current).toString();
        }
      },
      scrollTrigger: {
        trigger: ref.current,
        start: 'top 80%',
        toggleActions: 'play none none reverse',
      },
    });
  }, [target]);

  return <div ref={ref}>0</div>;
}
```

### Horizontal Scroll Section

```tsx
function HorizontalScroll() {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;

    gsap.to(containerRef.current, {
      x: () =>
        -(containerRef.current.scrollWidth - window.innerWidth),
      ease: 'none',
      scrollTrigger: {
        trigger: containerRef.current,
        start: 'center center',
        end: () => `+=${containerRef.current.scrollWidth}`,
        scrub: 1,
        pin: true,
        anticipatePin: 1,
      },
    });
  }, []);

  return (
    <div ref={containerRef} className="flex gap-6">
      {[1, 2, 3, 4, 5].map((item) => (
        <div key={item} className="flex-shrink-0 w-96 h-96 bg-gray-900">
          {item}
        </div>
      ))}
    </div>
  );
}
```

### Parallax Image Gallery

```tsx
function ParallaxGallery() {
  return (
    <div className="space-y-32">
      {[1, 2, 3].map((item) => (
        <ParallaxImage key={item} src={`/image-${item}.jpg`} />
      ))}
    </div>
  );
}

function ParallaxImage({ src }: { src: string }) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);

  return (
    <motion.div ref={ref} className="h-96 overflow-hidden rounded-lg">
      <motion.img
        src={src}
        style={{ y }}
        className="w-full h-full object-cover"
        alt="Parallax"
      />
    </motion.div>
  );
}
```

---

## Animation Best Practices

✅ **DO:**
- Use transform (translate, rotate, scale) and opacity
- Leverage GPU acceleration with will-change
- Create reusable animation components/hooks
- Test on real devices
- Respect prefers-reduced-motion
- Use requestAnimationFrame or GSAP (not setInterval)
- Clean up animations in useEffect return

❌ **DON'T:**
- Animate position properties (left, top, width, height)
- Use setInterval for animations
- Forget to clean up event listeners
- Create animations in rapid-fire renders
- Animate shadow, border-radius, or box-shadow
- Ignore performance on mobile devices
- Use too many simultaneous animations

---

## Additional Resources

- [GSAP Documentation](https://gsap.com/docs/v3)
- [Framer Motion Docs](https://www.framer.com/motion/)
- [Web Animations Best Practices](https://web.dev/animations/)
- [MDN Transform](https://developer.mozilla.org/en-US/docs/Web/CSS/transform)

---

**Master these patterns and create world-class animations! 🚀**
