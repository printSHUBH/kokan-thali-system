# Quick Start Guide - Nothing Landing Page

Get up and running in minutes.

## 📦 Installation (2 minutes)

```bash
# Clone/create project
mkdir nothing-landing && cd nothing-landing

# Copy all files from the provided files

# Install dependencies
npm install

# Start development server
npm run dev

# Open http://localhost:3000
```

## 🎯 First Things to Customize

### 1. Change Hero Text
Edit `nothing-landing.tsx`, find the hero section:

```tsx
<h2 className="text-white text-5xl font-light tracking-tight mb-4">
  Designed Different.  // ← Change this
</h2>
```

### 2. Update Feature Content
In the same file, update the features array:

```tsx
const features = [
  {
    title: 'Your Feature Title',  // ← Change
    description: 'Your description here',  // ← Change
    icon: '📱',  // ← Change emoji
  },
  // ...more features
];
```

### 3. Add Your Images
Replace placeholder components with real images:

```tsx
// Before
<div className="feature-element h-96 rounded-lg bg-gradient-to-br from-gray-900 to-black border border-gray-800 flex items-center justify-center text-4xl">
  {icon}
</div>

// After
<div className="feature-element h-96 rounded-lg overflow-hidden">
  <Image
    src="/your-image.webp"
    alt="Feature"
    width={400}
    height={400}
    className="w-full h-full object-cover"
  />
</div>
```

### 4. Update CTA Text & Links
Find all buttons and update:

```tsx
<button className="px-8 py-3 border border-white text-white hover:bg-white hover:text-black transition-all duration-300 rounded-lg">
  Explore Now  // ← Change this
</button>
```

### 5. Update Footer
Change company name and links:

```tsx
<h4 className="font-light text-lg mb-4">Nothing</h4>  // ← Your company
<p className="text-gray-400 text-sm">
  Designed Different. Built for Tomorrow.  // ← Your tagline
</p>
```

## 🎨 Customization Cheat Sheet

### Change Colors
- Black background: Search for `bg-black` and replace
- White text: Search for `text-white` and replace
- Borders: Search for `border-white` and customize opacity

### Change Fonts
Update `tailwind.config.js`:
```js
fontFamily: {
  sans: ['Your Font', 'sans-serif'],
  display: ['Your Font', 'sans-serif'],
}
```

### Adjust Animation Speed
Find in `nothing-landing.tsx`:
```tsx
duration: 6,  // ← Change this (seconds)
repeat: -1,   // ← Set to 0 to stop repeating
```

### Change Hero Phone Size
```tsx
<div className="relative w-48 h-96 rounded-3xl">  // ← w-48 h-96
```
- w-32 = smaller
- w-48 = medium (default)
- w-64 = larger

### Disable Animations
In `page.tsx`, comment out Lenis:
```tsx
// const lenis = new Lenis({ ... });  // Disabled
```

### Speed Up/Slow Down Scroll
In `page.tsx`:
```tsx
const lenis = new Lenis({
  duration: 1.2,  // ← Lower = faster, Higher = slower
});
```

## 📱 Responsive Breakpoints

Tailwind breakpoints already configured:

```tsx
md:w-96      // Medium (768px and up)
lg:text-5xl  // Large (1024px and up)
xl:grid-cols-4  // Extra large (1280px and up)
```

## 🚀 Deployment

### To Vercel (Recommended)
```bash
npm install -g vercel
vercel
# Follow prompts
```

### To Netlify
```bash
npm run build
# Drag /next folder to Netlify
```

### To Custom Server
```bash
npm run build
npm start
# Server runs on port 3000
```

## 🐛 Common Issues & Fixes

### Issue: Animations not smooth
**Fix:** Make sure Lenis is imported and initialized in `page.tsx`

### Issue: Images not showing
**Fix:** Check image paths, use `/public/image.webp` format

### Issue: Phone looks weird on mobile
**Fix:** Add responsive width classes:
```tsx
<div className="w-32 md:w-48 lg:w-64">
```

### Issue: Scroll animations not triggering
**Fix:** Ensure ScrollTrigger is registered:
```tsx
import ScrollTrigger from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);
```

### Issue: Page is slow
**Fix:** 
1. Check Chrome DevTools > Performance
2. Disable animations on slower devices
3. Optimize images to WebP format

## 📊 Performance Checklist

- [ ] Optimized images (WebP format)
- [ ] No console errors
- [ ] Mobile responsive
- [ ] Smooth animations (60 FPS)
- [ ] Fast Core Web Vitals
- [ ] Accessibility tested

## 🔍 Testing Locally

### Performance
```bash
# Build and test production
npm run build
npm start
# Open http://localhost:3000
# Use Chrome DevTools > Lighthouse
```

### Mobile Preview
```bash
# Get local IP
ipconfig getifaddr en0  # Mac
hostname -I            # Linux
ipconfig               # Windows

# Access from phone
http://YOUR-IP:3000
```

## 📚 File Quick Reference

| File | Purpose |
|------|---------|
| `nothing-landing.tsx` | Main component with all sections |
| `page.tsx` | Next.js page with Lenis scroll |
| `layout.tsx` | App root layout |
| `globals.css` | Global styles and animations |
| `tailwind.config.js` | Tailwind configuration |
| `animation-hooks.ts` | Reusable animation hooks |

## 🎓 Learning Path

1. **Day 1:** Customize text and images
2. **Day 2:** Change colors and fonts
3. **Day 3:** Adjust animation speeds
4. **Day 4:** Add your own components
5. **Day 5:** Deploy to production

## 💡 Pro Tips

1. **Use CSS Variables:** Add custom properties in globals.css for theme colors
2. **Create Reusable Components:** Move repeated patterns into separate files
3. **Test Early:** Check mobile and desktop constantly
4. **Performance First:** Use Chrome DevTools before optimizing
5. **Git Workflow:** Commit before major changes

## 🆘 Support Resources

- **Next.js:** https://nextjs.org/docs
- **GSAP:** https://gsap.com/docs/v3/
- **Framer Motion:** https://www.framer.com/motion/
- **Tailwind:** https://tailwindcss.com/docs
- **TypeScript:** https://www.typescriptlang.org/docs/

## 🚀 Next Steps

1. Customize the content
2. Add your product images
3. Update company info
4. Test on devices
5. Deploy to production
6. Collect analytics
7. A/B test CTAs

---

**You're ready to launch! Good luck! 🎉**
