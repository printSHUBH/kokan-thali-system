'use client';

import React, { useEffect, useRef, useState } from 'react';
import { useScroll, useTransform, motion } from 'framer-motion';
import gsap from 'gsap';
import ScrollTrigger from 'gsap/ScrollTrigger';

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

// ============================================
// HERO SECTION - Opening Animation + Phone Display
// ============================================
const OpeningAnimation = ({ onComplete }: { onComplete: () => void }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const particlesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timeline = gsap.timeline({ onComplete });

    // Phase 1: Dots appear and organize (0-1.5s)
    if (particlesRef.current) {
      const dots = particlesRef.current.querySelectorAll('.particle-dot');
      timeline.fromTo(
        dots,
        { opacity: 0, scale: 0 },
        { opacity: 1, scale: 1, duration: 0.8, stagger: 0.05 },
        0
      );
    }

    // Phase 2: Logo morph (1.5-3s)
    timeline.to(
      containerRef.current,
      { opacity: 1, duration: 0.5 },
      1.5
    );

    // Phase 3: Fade and zoom into hero (3-5s)
    timeline.to(
      containerRef.current,
      { opacity: 0, scale: 1.2, duration: 0.8 },
      3.5
    );

    return () => timeline.kill();
  }, [onComplete]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 bg-black z-50 flex items-center justify-center opacity-0"
    >
      <div
        ref={particlesRef}
        className="relative w-48 h-48"
      >
        {/* Particle dots forming a grid */}
        {[...Array(49)].map((_, i) => (
          <div
            key={i}
            className="particle-dot absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${(i % 7) * 20}%`,
              top: `${Math.floor(i / 7) * 20}%`,
            }}
          />
        ))}
        
        {/* Logo text placeholder */}
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-white text-4xl font-light tracking-tight">
            Nothing
          </h1>
        </div>
      </div>
    </div>
  );
};

// ============================================
// PHONE 3D ROTATION COMPONENT
// ============================================
const PhoneHero = () => {
  const phoneRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!phoneRef.current || !containerRef.current) return;

    // Continuous smooth rotation animation
    gsap.to(phoneRef.current, {
      rotationY: 360,
      duration: 6,
      repeat: -1,
      ease: 'none',
      transformOrigin: '50% 50% 0',
    });

    // Parallax on mouse move
    const handleMouseMove = (e: MouseEvent) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;

      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;

      gsap.to(phoneRef.current, {
        rotationX: y * 10,
        rotationY: x * 10,
        duration: 0.3,
        overwrite: 'auto',
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-screen flex items-center justify-center bg-black overflow-hidden"
    >
      {/* Floating particles background */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full opacity-20"
            initial={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
            }}
            animate={{
              y: -100,
              opacity: [0.2, 0.5, 0],
            }}
            transition={{
              duration: 4 + Math.random() * 2,
              repeat: Infinity,
              ease: 'easeOut',
            }}
          />
        ))}
      </div>

      {/* Phone container with 3D effect */}
      <div className="relative z-10 perspective">
        <div
          ref={phoneRef}
          className="relative w-48 h-96 rounded-3xl bg-gradient-to-br from-gray-900 to-black shadow-2xl"
          style={{
            transformStyle: 'preserve-3d',
            boxShadow: '0 30px 60px rgba(255,255,255,0.1)',
          }}
        >
          {/* Phone display */}
          <div className="absolute inset-2 rounded-3xl bg-gradient-to-br from-gray-800 to-black flex items-center justify-center">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full border border-white/20 mx-auto mb-4" />
              <p className="text-white text-xs opacity-50">Glyph Interface</p>
            </div>
          </div>

          {/* Glyph lights */}
          <div className="absolute top-6 right-6 w-3 h-3 rounded-full bg-cyan-400 animate-pulse" />
          <div className="absolute top-12 right-6 w-3 h-3 rounded-full bg-cyan-400 opacity-50" />
        </div>
      </div>

      {/* Hero text and CTA */}
      <motion.div
        className="absolute bottom-20 left-0 right-0 text-center z-20"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5, duration: 0.8 }}
      >
        <h2 className="text-white text-5xl font-light tracking-tight mb-4">
          Designed Different.
        </h2>
        <p className="text-gray-400 text-sm mb-8">
          Transparent. Innovative. Yours.
        </p>
        <motion.button
          className="px-8 py-3 border border-white text-white hover:bg-white hover:text-black transition-all duration-300 rounded-lg"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Explore Now
        </motion.button>

        {/* Scroll indicator */}
        <motion.div
          className="mt-12 flex justify-center"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <svg
            className="w-6 h-6 text-white opacity-50"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </motion.div>
      </motion.div>
    </div>
  );
};

// ============================================
// FEATURE SECTION COMPONENTS
// ============================================

interface FeatureSectionProps {
  title: string;
  description: string;
  icon: string;
  index: number;
}

const FeatureSection = ({
  title,
  description,
  icon,
  index,
}: FeatureSectionProps) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    gsap.fromTo(
      ref.current.querySelectorAll('.feature-element'),
      { opacity: 0, y: 50 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.1,
        scrollTrigger: {
          trigger: ref.current,
          start: 'top 80%',
          toggleActions: 'play none none reverse',
        },
      }
    );
  }, []);

  return (
    <motion.div
      ref={ref}
      className="min-h-screen bg-black text-white px-8 md:px-16 py-20 flex flex-col justify-center"
    >
      <div className="max-w-6xl mx-auto w-full">
        {index % 2 === 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="feature-element">
              <h3 className="text-5xl font-light mb-6 tracking-tight">
                {title}
              </h3>
              <p className="text-lg text-gray-300 leading-relaxed mb-8">
                {description}
              </p>
              <button className="px-6 py-2 border border-white/30 text-white hover:bg-white/5 transition-all">
                Learn More →
              </button>
            </div>
            <div className="feature-element h-96 rounded-lg bg-gradient-to-br from-gray-900 to-black border border-gray-800 flex items-center justify-center text-4xl">
              {icon}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="feature-element h-96 rounded-lg bg-gradient-to-br from-gray-900 to-black border border-gray-800 flex items-center justify-center text-4xl order-2 md:order-1">
              {icon}
            </div>
            <div className="feature-element order-1 md:order-2">
              <h3 className="text-5xl font-light mb-6 tracking-tight">
                {title}
              </h3>
              <p className="text-lg text-gray-300 leading-relaxed mb-8">
                {description}
              </p>
              <button className="px-6 py-2 border border-white/30 text-white hover:bg-white/5 transition-all">
                Learn More →
              </button>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
};

// ============================================
// PARALLAX SECTION
// ============================================
const ParallaxSection = () => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start start', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], [0, 300]);

  return (
    <motion.div
      ref={ref}
      className="relative min-h-screen bg-black overflow-hidden"
    >
      <motion.div style={{ y }} className="absolute inset-0">
        <div className="w-full h-full bg-gradient-to-b from-white/5 via-transparent to-transparent" />
      </motion.div>

      <div className="relative z-10 h-screen flex flex-col items-center justify-center px-8">
        <h2 className="text-white text-6xl font-light text-center max-w-4xl mb-6">
          Seamless Performance Meets Design Excellence
        </h2>
        <p className="text-gray-400 text-xl text-center max-w-2xl">
          Every frame is optimized. Every interaction feels premium.
        </p>
      </div>
    </motion.div>
  );
};

// ============================================
// GALLERY SECTION WITH HORIZONTAL SCROLL
// ============================================
const GallerySection = () => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!scrollContainerRef.current) return;

    gsap.to(scrollContainerRef.current, {
      x: () =>
        -(scrollContainerRef.current.scrollWidth -
          scrollContainerRef.current.offsetWidth),
      scrollTrigger: {
        trigger: scrollContainerRef.current,
        start: 'center center',
        end: 'center -500px',
        scrub: 1,
        markers: false,
      },
    });
  }, []);

  return (
    <div className="bg-black text-white py-20">
      <div className="px-8 mb-12">
        <h2 className="text-5xl font-light tracking-tight">
          Premium Craftsmanship
        </h2>
        <p className="text-gray-400 mt-4">Scroll to explore</p>
      </div>

      <div className="overflow-hidden">
        <div
          ref={scrollContainerRef}
          className="flex gap-6 px-8 pb-8"
          style={{ width: 'max-content' }}
        >
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="flex-shrink-0 w-96 h-64 rounded-xl bg-gradient-to-br from-gray-900 to-black border border-gray-800 flex items-center justify-center"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-center">
                <div className="text-4xl mb-4">📱</div>
                <p className="text-gray-400">Gallery Item {i + 1}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ============================================
// STICKY STORYTELLING SECTION
// ============================================
const StickySection = () => {
  const ref = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!contentRef.current) return;

    gsap.fromTo(
      contentRef.current.querySelectorAll('.story-item'),
      { opacity: 0, y: 50 },
      {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.2,
        scrollTrigger: {
          trigger: contentRef.current,
          start: 'top 60%',
          toggleActions: 'play none none reverse',
        },
      }
    );
  }, []);

  return (
    <div ref={ref} className="bg-black text-white">
      <div
        ref={contentRef}
        className="max-w-4xl mx-auto px-8 py-24 space-y-32"
      >
        {[
          {
            title: 'Innovation in Simplicity',
            description:
              'We believe that the most powerful technology is transparent. Not hidden. Not complex. Just there.',
          },
          {
            title: 'Built for the Future',
            description:
              'Every component, every line of code, every design decision is made with tomorrow in mind.',
          },
          {
            title: 'Your Stories Matter',
            description:
              'This device adapts to you. It learns from you. It becomes a part of your story.',
          },
        ].map((item, i) => (
          <motion.div key={i} className="story-item">
            <h3 className="text-4xl font-light mb-4 tracking-tight">
              {item.title}
            </h3>
            <p className="text-xl text-gray-400 leading-relaxed max-w-2xl">
              {item.description}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

// ============================================
// STATS/METRICS SECTION
// ============================================
const StatsSection = () => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    const stats = ref.current.querySelectorAll('.stat-number');

    stats.forEach((stat) => {
      const target = parseInt(stat.getAttribute('data-target') || '0');
      gsap.fromTo(
        stat,
        { textContent: 0 },
        {
          textContent: target,
          duration: 2,
          scrollTrigger: {
            trigger: ref.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
          snap: { textContent: 1 },
          onUpdate: function () {
            stat.textContent = Math.ceil(parseFloat(this.progress() * target));
          },
        }
      );
    });
  }, []);

  return (
    <div ref={ref} className="bg-gradient-to-b from-black to-gray-950 text-white py-20">
      <div className="max-w-6xl mx-auto px-8">
        <h2 className="text-5xl font-light mb-16 tracking-tight">
          By The Numbers
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {[
            { number: 5, label: 'Years of Innovation', unit: '+' },
            { number: 50, label: 'Countries Reached', unit: '+' },
            { number: 1000, label: 'Hours of Testing', unit: '+' },
            { number: 99, label: 'Durability Score', unit: '%' },
          ].map((stat, i) => (
            <motion.div
              key={i}
              className="bg-gray-900/50 border border-gray-800 rounded-lg p-8 text-center"
              whileHover={{ y: -5 }}
            >
              <div className="text-4xl font-light mb-2">
                <span
                  className="stat-number"
                  data-target={stat.number}
                >
                  0
                </span>
                <span>{stat.unit}</span>
              </div>
              <p className="text-gray-400 text-sm">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ============================================
// FOOTER
// ============================================
const Footer = () => {
  return (
    <footer className="bg-black border-t border-gray-900 text-white py-12">
      <div className="max-w-6xl mx-auto px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div>
            <h4 className="font-light text-lg mb-4">Nothing</h4>
            <p className="text-gray-400 text-sm">
              Designed Different. Built for Tomorrow.
            </p>
          </div>
          {['Products', 'Company', 'Support', 'Community'].map((section) => (
            <div key={section}>
              <h5 className="font-light text-sm mb-4 tracking-wide">
                {section}
              </h5>
              <ul className="space-y-2 text-gray-400 text-sm">
                {['Link One', 'Link Two', 'Link Three'].map((link) => (
                  <li key={link}>
                    <a href="#" className="hover:text-white transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-gray-900 pt-8 flex justify-between items-center text-gray-400 text-sm">
          <p>&copy; 2024 Nothing. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">
              Twitter
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Instagram
            </a>
            <a href="#" className="hover:text-white transition-colors">
              LinkedIn
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// ============================================
// MAIN LANDING PAGE COMPONENT
// ============================================
export default function LandingPage() {
  const [showOpening, setShowOpening] = useState(true);

  const features = [
    {
      title: 'Transparent Design',
      description:
        'Every layer revealed. Every detail visible. See the future of device design where transparency meets innovation.',
      icon: '💎',
    },
    {
      title: 'Advanced Camera System',
      description:
        'Capture light in its purest form. Multi-lens precision designed for the moments that matter most.',
      icon: '📷',
    },
    {
      title: 'Immersive Display',
      description:
        '120Hz refresh rate. 2K resolution. Colors so vivid they feel alive. A visual experience unlike any other.',
      icon: '✨',
    },
    {
      title: 'Performance Beast',
      description:
        'Powered by the latest processor. Engineered for speed. Optimized for everything you throw at it.',
      icon: '⚡',
    },
    {
      title: 'All-Day Battery',
      description:
        'Fast charging. Wireless power. Battery technology that thinks ahead and keeps up with your pace.',
      icon: '🔋',
    },
    {
      title: 'Glyph Interface',
      description:
        'Intelligent lights that communicate. Notifications that don\'t distract. A conversation with your device.',
      icon: '💡',
    },
  ];

  return (
    <main className="bg-black">
      {/* Opening animation overlay */}
      {showOpening && (
        <OpeningAnimation onComplete={() => setShowOpening(false)} />
      )}

      {/* Hero section with rotating phone */}
      <PhoneHero />

      {/* Feature sections */}
      {features.map((feature, i) => (
        <FeatureSection key={i} {...feature} index={i} />
      ))}

      {/* Parallax section */}
      <ParallaxSection />

      {/* Gallery section */}
      <GallerySection />

      {/* Sticky storytelling */}
      <StickySection />

      {/* Stats section */}
      <StatsSection />

      {/* Footer */}
      <Footer />
    </main>
  );
}
