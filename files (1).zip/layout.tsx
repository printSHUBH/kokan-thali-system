import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Nothing Phone - Designed Different',
  description:
    'Experience premium design meets futuristic innovation. Transparent. Innovative. Yours.',
  keywords: [
    'Nothing Phone',
    'Premium Design',
    'Transparent Hardware',
    'Glyph Interface',
  ],
  authors: [{ name: 'Nothing' }],
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://nothing.com',
    title: 'Nothing Phone - Designed Different',
    description:
      'Experience premium design meets futuristic innovation. Transparent. Innovative. Yours.',
    siteName: 'Nothing',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nothing Phone - Designed Different',
    description:
      'Experience premium design meets futuristic innovation. Transparent. Innovative. Yours.',
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 5,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        {/* Preload critical fonts */}
        <link
          rel="preconnect"
          href="https://fonts.googleapis.com"
        />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />

        {/* Performance: DNS prefetch for external resources */}
        <link
          rel="dns-prefetch"
          href="https://cdnjs.cloudflare.com"
        />

        {/* Favicon */}
        <link
          rel="icon"
          href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='50' fill='%23fff'/><circle cx='50' cy='50' r='45' fill='%23000'/></svg>"
        />

        {/* Theme color for mobile browser chrome */}
        <meta name="theme-color" content="#000000" />
      </head>

      <body className="bg-black text-white">
        {/* Smooth scroll container */}
        <div id="lenis-container">{children}</div>

        {/* Hidden elements for SEO */}
        <noscript>
          <p>
            This website requires JavaScript to display properly. Please enable
            JavaScript in your browser settings.
          </p>
        </noscript>
      </body>
    </html>
  );
}
