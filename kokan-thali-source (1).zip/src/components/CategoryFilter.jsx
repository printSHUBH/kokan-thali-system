import { SlidersHorizontal } from 'lucide-react'

export default function CategoryFilter({ categories, active, onChange }) {
  return (
    <div className="category-bar" role="tablist" aria-label="Food categories">
      <span className="category-intro"><SlidersHorizontal size={16} /> Browse by mood</span>
      <div className="category-scroll">
        {categories.map((category) => (
          <button key={category.id} role="tab" aria-selected={active === category.id} className={`category-pill ${active === category.id ? 'active' : ''}`} onClick={() => onChange(category.id)}>
            {category.label}
          </button>
        ))}
      </div>
    </div>
  )
}
