# Kokan Thali — Delivery TODO

## Responsive Konkan storefront shell
- [x] The SPA uses the approved forest green, terracotta, cream, coconut beige and olive palette with serif headings, sans-serif body text, Marathi-inspired details, coastal food photography, rounded cards, shadows and subtle motion.
- [x] A thin announcement bar reads “A little taste of the Konkan coast, delivered to your door.”
- [x] A sticky responsive Navbar includes shell/coconut branding, Home, Food Menu, Our Story, Contact, search, live cart count and an accessible mobile hamburger menu.

## Product discovery and menu
- [x] The hero reads “Coastal soul. Thali on your mind.” with authentic-flavour copy, food imagery, menu CTA, ratings, satisfaction details and decorative coastal elements.
- [x] Category filters include All Favourites, Kokan Thalis, Seafood Specials, Vegetarian Delights, Malvani Chicken, Rice and Breads, Snacks and Sweets, and Drinks and Sol Kadhi; selection filters without a page refresh.
- [x] The menu contains the 12 requested sample products with suitable imagery, descriptions, INR prices, ratings, delivery times, dietary markers, bestseller badges where relevant, favourite controls and quantity-aware add actions.
- [x] Search and sorting work alongside category filtering with loading, empty and error-friendly presentation.

## Cart and simulated checkout
- [x] Cart interactions add products, change quantities, remove products, update the live count, calculate subtotal and delivery dynamically, provide free delivery above ₹499, show final payable total, show an empty state, open as a drawer, and persist in localStorage.
- [x] Checkout validates customer name, mobile number, delivery address, city, PIN and payment method, displays the order summary and fee, simulates order placement, and shows a generated confirmation number without claiming real payment processing.

## Brand story, trust and footer
- [x] The page includes “Some flavours feel like home.”, “कोकणातून प्रेमाने” / “With love from Konkan.”, coastal-village storytelling, Why Choose Us, Fresh Ingredients, seasonal offer content, testimonials, newsletter subscription and a branded footer with navigation, social links and contact details.

## Code quality and handoff
- [x] The app uses React functional components, hooks, reusable components, semantic controls, responsive layouts for desktop/tablet/mobile, no hardcoded totals, and README instructions for `npm install` and `npm run dev`.
